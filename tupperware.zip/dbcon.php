<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=tupperware;', 'root', '');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}

?>